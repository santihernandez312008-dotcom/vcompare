<?php

session_start();
require_once "conexion.php";

function volver($mensaje)
{
    header("Location: login.php?error=" . urlencode($mensaje));
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Método no permitido");
}

$correo = trim($_POST["correo"] ?? "");
$clave = $_POST["clave"] ?? "";

if (!filter_var($correo, FILTER_VALIDATE_EMAIL) || $clave === "") {
    volver("Datos inválidos");
}

$sql = "SELECT id, nombre, clave FROM usuarios WHERE correo = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("s", $correo);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

$stmt->close();
$conexion->close();

if ($usuario && password_verify($clave, $usuario["clave"])) {
    session_regenerate_id(true);
    $_SESSION["id"] = $usuario["id"];
    $_SESSION["nombre"] = $usuario["nombre"];
    header("Location: index.php");
    exit;
}

volver("Correo o contraseña incorrectos");

?>