<?php

session_start();

if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bienvenida</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>

    <div class="tarjeta">
        <div class="logo">🚗</div>
        <h2>¡Bienvenido, <?php echo htmlspecialchars($_SESSION["nombre"]); ?>!</h2>
        <p class="subtitulo">Has iniciado sesión en el comparador de vehículos.</p>

        <a class="boton" href="logout.php">Cerrar sesión</a>
    </div>

</body>
</html>