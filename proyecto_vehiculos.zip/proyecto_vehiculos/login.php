<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iniciar sesión | V-Compare</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500&display=swap">
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
<div class="tarjeta">
    <div class="logo"><i>🚗</i>V-Compare</div>
    <h2>Iniciar sesión</h2>
    <p class="subtitulo">Bienvenido de nuevo</p>

    <?php if (isset($_GET["registrado"])): ?>
        <div class="mensaje exito">Cuenta creada correctamente. Ya puedes iniciar sesión.</div>
    <?php endif; ?>

    <?php if (isset($_GET["error"])): ?>
        <div class="mensaje error"><?php echo htmlspecialchars($_GET["error"]); ?></div>
    <?php endif; ?>

    <form action="validar.php" method="POST">
        <div class="campo">
            <label for="correo">Correo electrónico</label>
            <input type="email" id="correo" name="correo" maxlength="100" placeholder="nombre@dominio.com" required>
        </div>

        <div class="campo">
            <label for="clave">Contraseña</label>
            <div class="pw">
                <input type="password" id="clave" name="clave" maxlength="72" autocomplete="current-password" required>
                <button type="button" class="ver" id="ver">Mostrar</button>
            </div>
        </div>

        <button type="submit">Entrar</button>
    </form>

    <p class="enlace">¿No tienes cuenta? <a href="registro.php">Regístrate</a></p>
    <p class="enlace" style="margin-top:8px"><a href="index.php">Volver al inicio</a></p>
</div>

<script>
document.getElementById("ver").addEventListener("click", function () {
    const i = document.getElementById("clave"), ver = i.type === "password";
    i.type = ver ? "text" : "password";
    this.textContent = ver ? "Ocultar" : "Mostrar";
});
</script>
</body>
</html>