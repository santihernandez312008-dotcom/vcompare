<?php
session_start();
$error = $_SESSION["error"] ?? "";
$old = $_SESSION["old"] ?? ["nombre" => "", "apellido" => "", "correo" => ""];
unset($_SESSION["error"], $_SESSION["old"]);
$v = fn($k) => htmlspecialchars($old[$k] ?? "");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crear cuenta | V-Compare</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500&display=swap">
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
<div class="tarjeta">
    <div class="logo"><i>🚗</i>V-Compare</div>
    <h2>Crear cuenta</h2>
    <p class="subtitulo">Compara, analiza y elige tu vehículo</p>

    <?php if ($error): ?>
        <div class="mensaje error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form action="guardar.php" method="POST" id="form" novalidate>
        <div class="dos">
            <div class="campo">
                <label for="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" maxlength="50" value="<?php echo $v("nombre"); ?>" required>
            </div>
            <div class="campo">
                <label for="apellido">Apellido</label>
                <input type="text" id="apellido" name="apellido" maxlength="50" value="<?php echo $v("apellido"); ?>" required>
            </div>
        </div>
        <div class="ayuda" id="ay-nombre"></div>

        <div class="campo">
            <label for="correo">Correo electrónico</label>
            <input type="email" id="correo" name="correo" maxlength="100" value="<?php echo $v("correo"); ?>" placeholder="nombre@dominio.com" required>
            <div class="ayuda" id="ay-correo"></div>
        </div>

        <div class="campo">
            <label for="clave">Contraseña</label>
            <div class="pw">
                <input type="password" id="clave" name="clave" maxlength="72" autocomplete="new-password" required>
                <button type="button" class="ver" data-t="clave">Mostrar</button>
            </div>
            <ul class="reglas" id="reglas">
                <li data-r="len">8 caracteres o más</li>
                <li data-r="may">Una mayúscula</li>
                <li data-r="min">Una minúscula</li>
                <li data-r="num">Un número</li>
                <li data-r="esp">Un carácter especial</li>
                <li data-r="esp2">Sin espacios</li>
            </ul>
        </div>

        <div class="campo">
            <label for="clave2">Repetir contraseña</label>
            <div class="pw">
                <input type="password" id="clave2" name="clave2" maxlength="72" autocomplete="new-password" required>
                <button type="button" class="ver" data-t="clave2">Mostrar</button>
            </div>
            <div class="ayuda" id="ay-clave2"></div>
        </div>

        <button type="submit" id="enviar" disabled>Crear cuenta</button>
    </form>

    <p class="enlace">¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
</div>

<script>
const $ = id => document.getElementById(id);
const reNombre = /^[\p{L}][\p{L}\s'-]{1,49}$/u;
// el correo debe tener al menos una letra, dominio válido y extensión de 2+ letras (no solo números)
const reCorreo = /^(?=.*[A-Za-z])[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$/;
const reglas = {
    len: c => c.length >= 8,
    may: c => /[A-Z]/.test(c),
    min: c => /[a-z]/.test(c),
    num: c => /[0-9]/.test(c),
    esp: c => /[^A-Za-z0-9\s]/.test(c),
    esp2: c => c.length > 0 && !/\s/.test(c)
};

function validar() {
    const n = $("nombre").value.trim(), a = $("apellido").value.trim();
    const co = $("correo").value.trim(), c = $("clave").value, c2 = $("clave2").value;

    const okN = reNombre.test(n) && reNombre.test(a);
    $("ay-nombre").textContent = (n || a) && !okN ? "Usa solo letras (mínimo 2) en nombre y apellido." : "";

    const okC = reCorreo.test(co);
    $("ay-correo").textContent = co && !okC ? "Escribe un correo válido, por ejemplo nombre@dominio.com." : "";
    $("correo").className = co ? (okC ? "bien" : "mal") : "";

    let okP = true;
    document.querySelectorAll("#reglas li").forEach(li => {
        const cumple = reglas[li.dataset.r](c);
        li.classList.toggle("ok", cumple);
        okP = okP && cumple;
    });

    const okI = c2 !== "" && c === c2;
    $("ay-clave2").textContent = c2 && !okI ? "Las contraseñas no coinciden." : "";
    $("clave2").className = c2 ? (okI ? "bien" : "mal") : "";

    $("enviar").disabled = !(okN && okC && okP && okI);
}

document.querySelectorAll("input").forEach(i => i.addEventListener("input", validar));
document.querySelectorAll(".ver").forEach(b => b.addEventListener("click", () => {
    const i = $(b.dataset.t), ver = i.type === "password";
    i.type = ver ? "text" : "password";
    b.textContent = ver ? "Ocultar" : "Mostrar";
}));
validar();
</script>
</body>
</html>