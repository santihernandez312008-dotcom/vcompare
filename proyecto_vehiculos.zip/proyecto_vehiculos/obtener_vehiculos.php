<?php
header('Content-Type: application/json; charset=utf-8');

require_once 'conexion.php';

$sql = "SELECT
            v.id,
            m.nombre AS marca,
            c.nombre AS categoria,
            v.modelo,
            v.anio,
            v.precio,
            v.cilindraje,
            v.potencia,
            v.consumo,
            v.imagen
        FROM vehiculos v
        INNER JOIN marcas m ON v.marca_id = m.id
        INNER JOIN categorias c ON v.categoria_id = c.id
        ORDER BY v.id DESC";

$resultado = $conexion->query($sql);

if (!$resultado) {
    http_response_code(500);
    echo json_encode(
        ["error" => "Error al obtener los vehículos"],
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

$vehiculos = [];

while ($fila = $resultado->fetch_assoc()) {
    // mysqli entrega los números como texto; el index compara el id como número
    $fila["id"] = (int)$fila["id"];
    $fila["anio"] = (int)$fila["anio"];
    $fila["cilindraje"] = (int)$fila["cilindraje"];
    $vehiculos[] = $fila;
}

echo json_encode($vehiculos, JSON_UNESCAPED_UNICODE);

$conexion->close();
?>
