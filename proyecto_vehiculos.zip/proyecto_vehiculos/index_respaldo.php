<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Comparador de Vehículos</title>
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: #f8fafc; margin: 0; padding: 20px; color: #1e293b; }
        
        header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 15px; margin-bottom: 25px; }
        header h1 { margin: 0; font-size: 1.8rem; color: #0f172a; }
        
        .nav-btn { background-color: #2563eb; color: white; padding: 10px 18px; border-radius: 6px; text-decoration: none; font-weight: bold; font-size: 0.95rem; }
        .nav-btn:hover { background-color: #1d4ed8; }
        
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 20px; margin-bottom: 40px; }
        
        .card { background: white; border-radius: 8px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.05); display: flex; flex-direction: column; }
        .card img { width: 100%; height: 160px; object-fit: cover; background-color: #e2e8f0; }
        .card-body { padding: 15px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; }
        .card-title { margin: 5px 0 8px; font-size: 1.2rem; color: #0f172a; }
        .price { color: #16a34a; font-weight: bold; font-size: 1.1rem; margin-bottom: 12px; }
        
        .btn-action { background: #0284c7; color: white; border: none; padding: 10px; border-radius: 5px; cursor: pointer; width: 100%; font-weight: bold; }
        .btn-action.active { background: #dc2626; }

        #comparador { background: white; padding: 25px; border-radius: 8px; border: 1px solid #cbd5e1; box-shadow: 0 2px 4px rgba(0,0,0,0.03); }
        #comparador h2 { margin-top: 0; color: #0f172a; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #cbd5e1; padding: 12px; text-align: center; }
        th { background-color: #f1f5f9; color: #0f172a; }
    </style>
</head>
<body>

       <header>
        <h1>Dashboard Comparador de Vehículos</h1>
        <?php if (isset($_SESSION["id"])): ?>
            <div>
                <span style="margin-right: 12px;">Hola, <?php echo htmlspecialchars($_SESSION["nombre"]); ?></span>
                <a href="logout.php" class="nav-btn">Cerrar sesión</a>
            </div>
        <?php else: ?>
            <a href="login.php" class="nav-btn">Iniciar Sesión</a>
        <?php endif; ?>
    </header>
    <section>
        <h2>Catálogo de Vehículos</h2>
        <div id="grid-vehiculos" class="grid">
            <p>Cargando catálogo...</p>
        </div>
    </section>

    <section id="comparador">
        <h2>Módulo de Comparación Técnica</h2>
        <div id="tabla-comparativa">
            <p style="color: #64748b;">Selecciona hasta 3 vehículos del catálogo para compararlos lado a lado.</p>
        </div>
    </section>

    <script>
        let vehiculos = [];
        let seleccionados = [];

        async function cargarVehiculos() {
            const grid = document.getElementById('grid-vehiculos');
            try {
                // Agregar timestamp para evitar problemas de caché en el navegador
                const respuesta = await fetch('obtener_vehiculos.php?t=' + new Date().getTime());
                const textoPlano = await respuesta.text();
                
                // Convertir texto a JSON manualmente para prevenir errores de parsing
                vehiculos = JSON.parse(textoPlano);
                renderizarGrid();
            } catch (error) {
                console.error("Error al procesar datos:", error);
                grid.innerHTML = `<p style="color: red; font-weight: bold;">
                    Error al cargar los datos desde la base de datos.<br>
                    Detalle: ${error.message}
                </p>`;
            }
        }

        function renderizarGrid() {
            const grid = document.getElementById('grid-vehiculos');
            grid.innerHTML = '';

            if (!Array.isArray(vehiculos) || vehiculos.length === 0) {
                grid.innerHTML = '<p>No hay vehículos registrados en la base de datos.</p>';
                return;
            }

            vehiculos.forEach(v => {
                const estaSeleccionado = seleccionados.includes(v.id);
                const card = document.createElement('div');
                card.className = 'card';
                card.innerHTML = `
                    <img src="${v.imagen || 'img/default.png'}" alt="${v.modelo}" onerror="this.src='https://via.placeholder.com/300x180?text=Sin+Imagen'">
                    <div class="card-body">
                        <div>
                            <span style="font-size: 0.8rem; color: #2563eb; font-weight: bold; text-transform: uppercase;">${v.categoria}</span>
                            <h3 class="card-title">${v.marca} ${v.modelo} (${v.anio})</h3>
                            <div class="price">$${Number(v.precio).toLocaleString('es-CO')} COP</div>
                        </div>
                        <button class="btn-action ${estaSeleccionado ? 'active' : ''}" onclick="toggleSeleccion(${v.id})">
                            ${estaSeleccionado ? 'Quitar de Comparación' : 'Comparar'}
                        </button>
                    </div>
                `;
                grid.appendChild(card);
            });

            renderizarComparativa();
        }

        function toggleSeleccion(id) {
            if (seleccionados.includes(id)) {
                seleccionados = seleccionados.filter(vId => vId !== id);
            } else {
                if (seleccionados.length >= 3) {
                    alert('Solo puedes comparar un máximo de 3 vehículos simultáneamente.');
                    return;
                }
                seleccionados.push(id);
            }
            renderizarGrid();
        }

        function renderizarComparativa() {
            const contenedor = document.getElementById('tabla-comparativa');
            const lista = vehiculos.filter(v => seleccionados.includes(v.id));

            if (lista.length === 0) {
                contenedor.innerHTML = '<p style="color: #64748b;">Selecciona vehículos del catálogo para compararlos aquí lado a lado.</p>';
                return;
            }

            let html = `<table>
                <thead>
                    <tr>
                        <th>Característica</th>
                         ${lista.map(v => `<th>${v.marca} ${v.modelo}</th>`).join('')}
                    </tr>
                </thead>
                <tbody>
                    <tr><td><strong>Categoría</strong></td>${lista.map(v => `<td>${v.categoria}</td>`).join('')}</tr>
                    <tr><td><strong>Año</strong></td>${lista.map(v => `<td>${v.anio}</td>`).join('')}</tr>
                    <tr><td><strong>Precio</strong></td>${lista.map(v => `<td>$${Number(v.precio).toLocaleString('es-CO')} COP</td>`).join('')}</tr>
                    <tr><td><strong>Cilindraje</strong></td>${lista.map(v => `<td>${v.cilindraje} cc</td>`).join('')}</tr>
                    <tr><td><strong>Potencia</strong></td>${lista.map(v => `<td>${v.potencia}</td>`).join('')}</tr>
                    <tr><td><strong>Consumo</strong></td>${lista.map(v => `<td>${v.consumo}</td>`).join('')}</tr>
                </tbody>
            </table>`;

            contenedor.innerHTML = html;
        }

        cargarVehiculos();
    </script>
</body>
</html>