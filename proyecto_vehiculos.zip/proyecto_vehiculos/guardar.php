<?php

session_start();
require_once "conexion.php";

// Devuelve al registro con el mensaje y conserva lo que escribió el usuario
function volver($mensaje)
{
    $_SESSION["error"] = $mensaje;
    $_SESSION["old"] = [
        "nombre" => $_POST["nombre"] ?? "",
        "apellido" => $_POST["apellido"] ?? "",
        "correo" => $_POST["correo"] ?? ""
    ];
    header("Location: registro.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Método no permitido");
}

$nombre = trim($_POST["nombre"] ?? "");
$apellido = trim($_POST["apellido"] ?? "");
$correo = strtolower(trim($_POST["correo"] ?? ""));
$clave = $_POST["clave"] ?? "";
$clave2 = $_POST["clave2"] ?? "";

// Nombre y apellido: solo letras, espacios, apóstrofe o guion (2 a 50)
$reNombre = "/^[\p{L}][\p{L}\s'-]{1,49}$/u";
if (!preg_match($reNombre, $nombre) || !preg_match($reNombre, $apellido)) {
    volver("Nombre y apellido deben tener solo letras (mínimo 2).");
}

// Correo: formato válido, al menos una letra, dominio con extensión de 2+ letras
$reCorreo = "/^(?=.*[A-Za-z])[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$/";
if (
    strlen($correo) > 100 ||
    !filter_var($correo, FILTER_VALIDATE_EMAIL) ||
    !preg_match($reCorreo, $correo)
) {
    volver("Escribe un correo válido, por ejemplo nombre@dominio.com.");
}

// Contraseña: 8 a 72 caracteres, mayúscula, minúscula, número, carácter especial y sin espacios
if (
    strlen($clave) < 8 ||
    strlen($clave) > 72 ||
    !preg_match("/[A-Z]/", $clave) ||
    !preg_match("/[a-z]/", $clave) ||
    !preg_match("/[0-9]/", $clave) ||
    !preg_match("/[^A-Za-z0-9\s]/", $clave) ||
    preg_match("/\s/", $clave)
) {
    volver("La contraseña debe tener 8 caracteres o más, una mayúscula, una minúscula, un número, un carácter especial y no llevar espacios.");
}

if ($clave !== $clave2) {
    volver("Las contraseñas no coinciden.");
}

// Verificar que el correo no esté registrado
$stmt = $conexion->prepare("SELECT id FROM usuarios WHERE correo = ?");
$stmt->bind_param("s", $correo);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->close();
    volver("Ese correo ya está registrado.");
}
$stmt->close();

// Encriptar la contraseña
$hash = password_hash($clave, PASSWORD_DEFAULT);

$stmt = $conexion->prepare(
    "INSERT INTO usuarios (nombre, apellido, correo, clave) VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("ssss", $nombre, $apellido, $correo, $hash);

if ($stmt->execute()) {
    $stmt->close();
    $conexion->close();
    unset($_SESSION["error"], $_SESSION["old"]);
    header("Location: login.php?registrado=1");
    exit;
}

$stmt->close();
$conexion->close();
volver("No fue posible crear la cuenta. Inténtalo de nuevo.");

?>