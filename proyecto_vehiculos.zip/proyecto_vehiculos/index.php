<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>V-Compare | Compara. Analiza. Elige.</title>
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root{--bg:#0a0b0d;--s:#111318;--b:#1f2430;--p:#3b82f6;--t:#e8eaee;--m:#8b93a1}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:'Outfit','Segoe UI',sans-serif;background:var(--bg);color:var(--t);line-height:1.5}
a{color:inherit;text-decoration:none}
.wrap{max-width:1180px;margin:0 auto;padding:0 24px}
nav{position:sticky;top:0;z-index:10;background:rgba(10,11,13,.92);backdrop-filter:blur(8px);border-bottom:1px solid var(--b)}
nav .wrap{display:flex;align-items:center;justify-content:space-between;height:72px;gap:16px}
.logo{display:flex;align-items:center;gap:12px;font-size:1.25rem;font-weight:500}
.logo i{width:40px;height:40px;border-radius:10px;background:var(--p);display:grid;place-items:center;font-style:normal;box-shadow:0 0 18px rgba(59,130,246,.45)}
.links{display:flex;gap:6px}
.links a{padding:9px 16px;border-radius:8px;color:var(--m);font-size:.95rem}
.links a:hover,.links a.on{color:#fff;background:var(--s)}
.btn{display:inline-block;background:var(--p);color:#fff;padding:12px 22px;border-radius:10px;font-weight:500;border:0;cursor:pointer;font-family:inherit;font-size:1rem;box-shadow:0 6px 20px rgba(59,130,246,.35)}
.btn:hover{background:#2563eb}
.btn.ghost{background:var(--s);border:1px solid var(--b);box-shadow:none;color:var(--m)}
.user{display:flex;align-items:center;gap:12px;color:var(--m);font-size:.9rem}
#inicio{background:linear-gradient(90deg,var(--bg) 30%,rgba(10,11,13,.45)),url('img/auto.png') center right/cover;padding:110px 0 70px;border-bottom:1px solid var(--b)}
.tag{display:inline-block;border:1px solid #1e3a8a;background:#0f1a33;color:var(--p);padding:8px 18px;border-radius:99px;font-size:.8rem;letter-spacing:.06em;margin-bottom:28px}
h1{font-size:clamp(3rem,8vw,5.6rem);line-height:1;font-weight:500;letter-spacing:-.03em}
h1 span{color:var(--p)}
.lead{color:var(--m);font-size:1.25rem;max-width:520px;margin:26px 0 34px}
.cta{display:flex;gap:14px;flex-wrap:wrap}
.stats{display:flex;gap:44px;margin-top:56px;padding-top:34px;border-top:1px solid var(--b);max-width:620px}
.stats b{display:block;font-size:2rem;font-weight:500}
.stats small{color:var(--m)}
section.blk{padding:80px 0;border-bottom:1px solid var(--b)}
.sub{color:var(--m);font-size:.85rem;letter-spacing:.1em;text-transform:uppercase}
h2{font-size:2.2rem;font-weight:500;letter-spacing:-.02em;margin:6px 0 32px}
.cats{display:flex;gap:14px;flex-wrap:wrap}
.cat{flex:1;min-width:140px;background:var(--s);border:1px solid var(--b);color:var(--m);border-radius:16px;padding:34px 12px;font:inherit;font-size:1rem;cursor:pointer}
.cat:hover{border-color:#2a3350}
.cat.on{background:#0f1a33;border-color:var(--p);color:#fff;box-shadow:0 0 22px rgba(59,130,246,.25)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:20px}
.card{background:var(--s);border:1px solid var(--b);border-radius:16px;overflow:hidden;display:flex;flex-direction:column}
.card.sel{border-color:var(--p);box-shadow:0 0 22px rgba(59,130,246,.25)}
.card img{width:100%;height:170px;object-fit:cover;background:#1a1d25}
.cb{padding:18px;display:flex;flex-direction:column;gap:6px;flex:1}
.row{display:flex;justify-content:space-between;color:var(--m);font-size:.85rem;letter-spacing:.08em;text-transform:uppercase}
.cb h3{font-size:1.2rem;font-weight:500}
.chip{align-self:flex-start;font-size:.78rem;padding:3px 12px;border-radius:99px;border:1px solid var(--b);color:var(--m)}
.foot{margin-top:auto;padding-top:14px;border-top:1px solid var(--b);display:flex;justify-content:space-between;align-items:center}
.foot b{font-size:1.15rem;font-weight:500}
.mini{background:var(--bg);border:1px solid var(--b);color:var(--t);padding:8px 14px;border-radius:8px;cursor:pointer;font:inherit;font-size:.9rem}
.mini:hover{border-color:var(--p)}
.mini.on{background:var(--p);border-color:var(--p)}
.tw{overflow-x:auto;background:var(--s);border:1px solid var(--b);border-radius:16px}
table{width:100%;border-collapse:collapse;min-width:560px}
th,td{padding:18px 22px;text-align:center;border-bottom:1px solid var(--b);border-right:1px solid var(--b)}
th:last-child,td:last-child{border-right:0}
tr:last-child td{border-bottom:0}
th:first-child,td:first-child{text-align:left;color:var(--m)}
td{color:var(--m)}
td.best{color:#fff}
td.best em{font-style:normal;font-size:.68rem;color:var(--p);background:#14244a;padding:3px 8px;border-radius:6px;margin-left:8px}
th img{width:90px;height:56px;object-fit:cover;border-radius:8px;display:block;margin:0 auto 8px}
.msg{color:var(--m);padding:28px;text-align:center}
.err{color:#f87171}
footer .wrap{display:flex;justify-content:space-between;align-items:center;padding:40px 24px;color:var(--m);font-size:.9rem;flex-wrap:wrap;gap:12px}
footer em{font-style:italic}
@media(max-width:820px){.links{display:none}.stats{gap:24px}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}
</style>
</head>
<body>

<nav>
  <div class="wrap">
    <a class="logo" href="#inicio"><i>🚗</i>V-Compare</a>
    <div class="links">
      <a class="on" href="#inicio">Inicio</a>
      <a href="#comparar">Comparar</a>
      <a href="#vehiculos">Vehículos</a>
      <?php if (!isset($_SESSION["id"])): ?><a href="login.php">Iniciar sesión</a><?php endif; ?>
    </div>
    <?php if (isset($_SESSION["id"])): ?>
      <div class="user">Hola, <?php echo htmlspecialchars($_SESSION["nombre"]); ?>
        <a class="btn" href="logout.php">Cerrar sesión</a></div>
    <?php else: ?>
      <a class="btn" href="#comparar">Comparar ahora</a>
    <?php endif; ?>
  </div>
</nav>

<header id="inicio">
  <div class="wrap">
    <span class="tag">● COMPARADOR DE VEHÍCULOS</span>
    <h1>Compara.<br><span>Analiza.</span><br>Elige.</h1>
    <p class="lead">Encuentra el vehículo que realmente se adapta a ti.</p>
    <div class="cta">
      <a class="btn" href="#comparar">Comparar vehículos</a>
      <a class="btn ghost" href="#vehiculos">Explorar catálogo</a>
    </div>
    <div class="stats">
      <div><b id="n-veh">–</b><small>Vehículos</small></div>
      <div><b id="n-mar">–</b><small>Marcas</small></div>
      <div><b id="n-cat">–</b><small>Categorías</small></div>
    </div>
  </div>
</header>

<section class="blk" id="vehiculos">
  <div class="wrap">
    <div class="sub">Categorías</div>
    <h2>Selecciona el tipo de vehículo</h2>
    <div class="cats" id="cats"></div>
    <div class="grid" id="grid" style="margin-top:40px"><p class="msg">Cargando catálogo...</p></div>
  </div>
</section>

<section class="blk" id="comparar">
  <div class="wrap">
    <div class="sub">Comparación directa</div>
    <h2>Compara tus opciones</h2>
    <div class="tw" id="tabla"></div>
  </div>
</section>

<footer>
  <div class="wrap">
    <a class="logo" href="#inicio"><i>🚗</i>V-Compare</a>
    <em>Compara. Analiza. Elige.</em>
    <span>© 2026</span>
  </div>
</footer>

<script>
let V = [], S = [], cat = 'Todos';
const $ = id => document.getElementById(id);
const fmt = n => '$' + Number(n).toLocaleString('es-CO');
const img = v => v.imagen || 'img/default.png';
const fallback = "this.onerror=null;this.src='img/default.png'";

async function cargar() {
  try {
    const r = await fetch('obtener_vehiculos.php?t=' + Date.now());
    V = await r.json();
    if (!Array.isArray(V)) throw new Error(V.error || 'Respuesta inválida');
    const cats = [...new Set(V.map(v => v.categoria))];
    $('n-veh').textContent = V.length;
    $('n-mar').textContent = new Set(V.map(v => v.marca)).size;
    $('n-cat').textContent = cats.length;
    pintarCats(cats);
    pintar();
  } catch (e) {
    $('grid').innerHTML = `<p class="msg err">No se pudo cargar el catálogo: ${e.message}</p>`;
  }
}

function pintarCats(cats) {
  $('cats').innerHTML = ['Todos', ...cats].map(c =>
    `<button class="cat ${c === cat ? 'on' : ''}" onclick="elegirCat('${c}')">${c}</button>`).join('');
}
function elegirCat(c) { cat = c; pintarCats([...new Set(V.map(v => v.categoria))]); pintar(); }

function pintar() {
  const lista = V.filter(v => cat === 'Todos' || v.categoria === cat);
  $('grid').innerHTML = lista.length ? lista.map(v => {
    const on = S.includes(v.id);
    return `<div class="card ${on ? 'sel' : ''}">
      <img src="${img(v)}" alt="${v.modelo}" onerror="${fallback}">
      <div class="cb">
        <div class="row"><span>${v.marca}</span><span>${v.anio}</span></div>
        <h3>${v.modelo}</h3>
        <span class="chip">${v.categoria}</span>
        <div class="foot"><b>${fmt(v.precio)}</b>
          <button class="mini ${on ? 'on' : ''}" onclick="alternar(${v.id})">${on ? 'Quitar' : 'Comparar'}</button></div>
      </div></div>`;
  }).join('') : '<p class="msg">No hay vehículos en esta categoría.</p>';
  tabla();
}

function alternar(id) {
  if (S.includes(id)) S = S.filter(x => x !== id);
  else if (S.length >= 3) { alert('Solo puedes comparar hasta 3 vehículos.'); return; }
  else S.push(id);
  pintar();
}

function tabla() {
  const L = V.filter(v => S.includes(v.id));
  if (!L.length) { $('tabla').innerHTML = '<p class="msg">Elige hasta 3 vehículos del catálogo con el botón Comparar.</p>'; return; }
  // [etiqueta, texto, valor numérico, mejor = min | max | null]
  const filas = [
    ['Precio', v => fmt(v.precio), v => +v.precio, 'min'],
    ['Año', v => v.anio],
    ['Categoría', v => v.categoria],
    ['Cilindraje', v => v.cilindraje + ' cc'],
    ['Potencia', v => v.potencia, v => parseFloat(v.potencia), 'max'],
    ['Consumo', v => v.consumo, v => parseFloat(v.consumo), 'min']
  ];
  let h = '<table><thead><tr><th>Especificación</th>' + L.map(v =>
    `<th><img src="${img(v)}" alt="" onerror="${fallback}">${v.marca} ${v.modelo}</th>`).join('') + '</tr></thead><tbody>';
  filas.forEach(([n, t, num, modo]) => {
    let mejor = null;
    if (modo && L.length > 1) { const vals = L.map(num); mejor = modo === 'min' ? Math.min(...vals) : Math.max(...vals); }
    h += `<tr><td>${n}</td>` + L.map(v => {
      const gana = mejor !== null && num(v) === mejor;
      return `<td class="${gana ? 'best' : ''}">${t(v)}${gana ? '<em>MEJOR</em>' : ''}</td>`;
    }).join('') + '</tr>';
  });
  $('tabla').innerHTML = h + '</tbody></table>';
}

cargar();
</script>
</body>
</html>